<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");

require_once '../config/conexion.php';

$conexion = new Conexion();
$db = $conexion->getConexion();

try {
    $query = "SELECT isbn, titulo, autor, editorial FROM libros ORDER BY titulo ASC";
    $stmt = $db->prepare($query);
    $stmt->execute();

    $num = $stmt->rowCount();

    if ($num > 0) {
        $libros_arr = array();
        $libros_arr["libros"] = array();

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            // Extraer fila
            extract($row);

            $libro_item = array(
                "isbn" => $isbn,
                "titulo" => $titulo,
                "autor" => $autor,
                "editorial" => $editorial
            );

            array_push($libros_arr["libros"], $libro_item);
        }

        http_response_code(200); // OK
        echo json_encode($libros_arr);
    } else {
        http_response_code(200); // OK, pero vacío
        echo json_encode(["libros" => []]);
    }
} catch (PDOException $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(["mensaje" => "Error de base de datos: " . $e->getMessage()]);
}
?>
