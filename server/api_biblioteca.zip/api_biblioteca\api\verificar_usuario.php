<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/conexion.php';

$conexion = new Conexion();
$db = $conexion->getConexion();

$data = json_decode(file_get_contents("php://input"));

if (!empty($data->username) && !empty($data->password)) {
    try {
        $query = "SELECT id, username, email, password FROM usuarios WHERE username = :username";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':username', $data->username);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $hashed_password = $row['password'];

            if (password_verify($data->password, $hashed_password)) {
                http_response_code(200); // OK
                echo json_encode([
                    "exito" => true,
                    "mensaje" => "Login exitoso.",
                    "usuario" => [
                        "id" => $row['id'],
                        "username" => $row['username'],
                        "email" => $row['email']
                    ]
                ]);
            } else {
                http_response_code(401); // Unauthorized
                echo json_encode(["exito" => false, "mensaje" => "Contraseña incorrecta."]);
            }
        } else {
            http_response_code(404); // Not Found
            echo json_encode(["exito" => false, "mensaje" => "Usuario no encontrado."]);
        }
    } catch (PDOException $e) {
        http_response_code(500); // Internal Server Error
        echo json_encode(["exito" => false, "mensaje" => "Error de base de datos: " . $e->getMessage()]);
    }
} else {
    http_response_code(400); // Bad Request
    echo json_encode(["exito" => false, "mensaje" => "Faltan datos. Asegúrese de enviar username y password."]);
}
?>
