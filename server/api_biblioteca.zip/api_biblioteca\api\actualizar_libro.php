<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: PUT"); // o POST si Volley da problemas con PUT

require_once '../config/conexion.php';

$conexion = new Conexion();
$db = $conexion->getConexion();

// Obtener datos enviados en JSON
$data = json_decode(file_get_contents("php://input"));

// Se necesita el ISBN para identificar qué actualizar
if (!empty($data->isbn) && !empty($data->titulo) && !empty($data->autor) && !empty($data->editorial)) {
    try {
        $query = "UPDATE libros SET titulo = :titulo, autor = :autor, editorial = :editorial WHERE isbn = :isbn";
        $stmt = $db->prepare($query);

        $stmt->bindParam(':isbn', $data->isbn);
        $stmt->bindParam(':titulo', $data->titulo);
        $stmt->bindParam(':autor', $data->autor);
        $stmt->bindParam(':editorial', $data->editorial);

        if ($stmt->execute()) {
            // Verificar si realmente se actualizó algún registro
            if($stmt->rowCount() > 0) {
                http_response_code(200); // OK
                echo json_encode(["exito" => true, "mensaje" => "Libro actualizado exitosamente."]);
            } else {
                http_response_code(404); // Not Found
                echo json_encode(["exito" => false, "mensaje" => "No se encontró el libro con el ISBN proporcionado."]);
            }
        } else {
            http_response_code(503); // Service Unavailable
            echo json_encode(["exito" => false, "mensaje" => "No se pudo actualizar el libro."]);
        }
    } catch (PDOException $e) {
        http_response_code(500); // Internal Server Error
        echo json_encode(["exito" => false, "mensaje" => "Error de base de datos: " . $e->getMessage()]);
    }
} else {
    http_response_code(400); // Bad Request
    echo json_encode(["exito" => false, "mensaje" => "Faltan datos. Asegúrese de enviar isbn, titulo, autor y editorial."]);
}
?>
