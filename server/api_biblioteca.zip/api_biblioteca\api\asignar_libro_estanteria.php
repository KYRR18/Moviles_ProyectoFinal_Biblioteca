<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/conexion.php';

$conexion = new Conexion();
$db = $conexion->getConexion();

$data = json_decode(file_get_contents("php://input"));

if (!empty($data->estanteria_id) && !empty($data->libro_id)) {
    try {
        $query = "INSERT INTO estanteria_libro (estanteria_id, libro_id) VALUES (:estanteria_id, :libro_id)";
        $stmt = $db->prepare($query);

        $stmt->bindParam(':estanteria_id', $data->estanteria_id);
        $stmt->bindParam(':libro_id', $data->libro_id);

        if ($stmt->execute()) {
            http_response_code(201); // Created
            echo json_encode(["exito" => true, "mensaje" => "Libro asignado a la estantería exitosamente."]);
        } else {
            http_response_code(503); // Service Unavailable
            echo json_encode(["exito" => false, "mensaje" => "No se pudo asignar el libro."]);
        }
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { // Duplicate entry or Foreign Key failure
            http_response_code(400); // Bad Request
            echo json_encode(["exito" => false, "mensaje" => "El libro ya está en esta estantería o IDs inválidos."]);
        } else {
            http_response_code(500); // Internal Server Error
            echo json_encode(["exito" => false, "mensaje" => "Error de base de datos: " . $e->getMessage()]);
        }
    }
} else {
    http_response_code(400); // Bad Request
    echo json_encode(["exito" => false, "mensaje" => "Faltan datos. Asegúrese de enviar estanteria_id y libro_id."]);
}
?>
