<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");

require_once '../config/conexion.php';

$conexion = new Conexion();
$db = $conexion->getConexion();

if (isset($_GET['usuario_id'])) {
    try {
        $query = "SELECT id, titulo FROM estanterias WHERE usuario_id = :usuario_id";
        $stmt = $db->prepare($query);

        $stmt->bindParam(':usuario_id', $_GET['usuario_id']);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $estanterias = [];
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $estanterias[] = $row;
            }
            http_response_code(200); // OK
            echo json_encode(["exito" => true, "estanterias" => $estanterias]);
        } else {
            http_response_code(404); // Not Found
            echo json_encode(["exito" => false, "mensaje" => "No se encontraron estanterías para este usuario."]);
        }
    } catch (PDOException $e) {
        http_response_code(500); // Internal Server Error
        echo json_encode(["exito" => false, "mensaje" => "Error de base de datos: " . $e->getMessage()]);
    }
} else {
    http_response_code(400); // Bad Request
    echo json_encode(["exito" => false, "mensaje" => "Faltan datos. Asegúrese de enviar usuario_id en la URL."]);
}
?>
