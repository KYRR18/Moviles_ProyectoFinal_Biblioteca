<?php
// db_config.php
define('DB_HOST', 'localhost');
define('DB_USER', 'root'); // Usuario por defecto en XAMPP
define('DB_PASS', '');     // Contraseña por defecto en XAMPP (vacía)
define('DB_NAME', 'biblioteca_db');
?>
