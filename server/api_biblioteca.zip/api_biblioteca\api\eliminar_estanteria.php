<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/conexion.php';

$conexion = new Conexion();
$db = $conexion->getConexion();

$data = json_decode(file_get_contents("php://input"));

if (!empty($data->estanteria_id)) {
    try {
        // First delete all relations in estanteria_libro for this shelf
        $queryRelations = "DELETE FROM estanteria_libro WHERE estanteria_id = :estanteria_id";
        $stmtRelations = $db->prepare($queryRelations);
        $stmtRelations->bindParam(':estanteria_id', $data->estanteria_id);
        $stmtRelations->execute();

        // Then delete the shelf itself
        $queryShelf = "DELETE FROM estanterias WHERE id = :estanteria_id";
        $stmtShelf = $db->prepare($queryShelf);
        $stmtShelf->bindParam(':estanteria_id', $data->estanteria_id);
        
        if ($stmtShelf->execute()) {
            if ($stmtShelf->rowCount() > 0) {
                http_response_code(200); // OK
                echo json_encode(["exito" => true, "mensaje" => "Estantería eliminada exitosamente."]);
            } else {
                http_response_code(404); // Not Found
                echo json_encode(["exito" => false, "mensaje" => "No se encontró la estantería."]);
            }
        } else {
            http_response_code(503); // Service Unavailable
            echo json_encode(["exito" => false, "mensaje" => "No se pudo eliminar la estantería."]);
        }
    } catch (PDOException $e) {
        http_response_code(500); // Internal Server Error
        echo json_encode(["exito" => false, "mensaje" => "Error de base de datos: " . $e->getMessage()]);
    }
} else {
    http_response_code(400); // Bad Request
    echo json_encode(["exito" => false, "mensaje" => "Faltan datos. Asegúrese de enviar estanteria_id."]);
}
?>
