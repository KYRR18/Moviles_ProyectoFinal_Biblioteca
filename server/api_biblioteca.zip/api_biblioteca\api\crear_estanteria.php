<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/conexion.php';

$conexion = new Conexion();
$db = $conexion->getConexion();

$data = json_decode(file_get_contents("php://input"));

if (!empty($data->usuario_id) && !empty($data->titulo)) {
    try {
        $query = "INSERT INTO estanterias (titulo, usuario_id) VALUES (:titulo, :usuario_id)";
        $stmt = $db->prepare($query);

        $stmt->bindParam(':titulo', $data->titulo);
        $stmt->bindParam(':usuario_id', $data->usuario_id);

        if ($stmt->execute()) {
            http_response_code(201); // Created
            echo json_encode(["exito" => true, "mensaje" => "Estantería creada exitosamente.", "id" => $db->lastInsertId()]);
        } else {
            http_response_code(503); // Service Unavailable
            echo json_encode(["exito" => false, "mensaje" => "No se pudo crear la estantería."]);
        }
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { // Foreign key constraint fails
            http_response_code(400); // Bad Request
            echo json_encode(["exito" => false, "mensaje" => "El usuario especificado no existe."]);
        } else {
            http_response_code(500); // Internal Server Error
            echo json_encode(["exito" => false, "mensaje" => "Error de base de datos: " . $e->getMessage()]);
        }
    }
} else {
    http_response_code(400); // Bad Request
    echo json_encode(["exito" => false, "mensaje" => "Faltan datos. Asegúrese de enviar usuario_id y titulo."]);
}
?>
