<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: DELETE"); // o POST si prefieres evitar métodos DELETE

require_once '../config/conexion.php';

$conexion = new Conexion();
$db = $conexion->getConexion();

// Obtener el ISBN del JSON
$data = json_decode(file_get_contents("php://input"));

if (!empty($data->isbn)) {
    try {
        $query = "DELETE FROM libros WHERE isbn = :isbn";
        $stmt = $db->prepare($query);

        $stmt->bindParam(':isbn', $data->isbn);

        if ($stmt->execute()) {
            if($stmt->rowCount() > 0) {
                http_response_code(200); // OK
                echo json_encode(["exito" => true, "mensaje" => "Libro eliminado exitosamente."]);
            } else {
                http_response_code(404); // Not Found
                echo json_encode(["exito" => false, "mensaje" => "No se encontró el libro con el ISBN proporcionado."]);
            }
        } else {
            http_response_code(503); // Service Unavailable
            echo json_encode(["exito" => false, "mensaje" => "No se pudo eliminar el libro."]);
        }
    } catch (PDOException $e) {
        http_response_code(500); // Internal Server Error
        echo json_encode(["exito" => false, "mensaje" => "Error de base de datos: " . $e->getMessage()]);
    }
} else {
    http_response_code(400); // Bad Request
    echo json_encode(["exito" => false, "mensaje" => "Falta el ISBN. No se especificó el libro a eliminar."]);
}
?>
