<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");

require_once '../config/conexion.php';

$conexion = new Conexion();
$db = $conexion->getConexion();

if (isset($_GET['estanteria_id'])) {
    try {
        $query = "SELECT l.id, l.isbn, l.titulo, l.autor, l.editorial 
                  FROM libros l
                  INNER JOIN estanteria_libro el ON l.id = el.libro_id
                  WHERE el.estanteria_id = :estanteria_id";
        $stmt = $db->prepare($query);

        $stmt->bindParam(':estanteria_id', $_GET['estanteria_id']);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $libros = [];
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $libros[] = $row;
            }
            http_response_code(200); // OK
            echo json_encode(["exito" => true, "libros" => $libros]);
        } else {
            http_response_code(404); // Not Found
            echo json_encode(["exito" => false, "mensaje" => "No se encontraron libros en esta estantería."]);
        }
    } catch (PDOException $e) {
        http_response_code(500); // Internal Server Error
        echo json_encode(["exito" => false, "mensaje" => "Error de base de datos: " . $e->getMessage()]);
    }
} else {
    http_response_code(400); // Bad Request
    echo json_encode(["exito" => false, "mensaje" => "Faltan datos. Asegúrese de enviar estanteria_id en la URL."]);
}
?>
