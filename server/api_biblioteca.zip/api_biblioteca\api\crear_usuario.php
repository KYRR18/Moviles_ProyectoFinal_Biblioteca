<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/conexion.php';

$conexion = new Conexion();
$db = $conexion->getConexion();

$data = json_decode(file_get_contents("php://input"));

if (!empty($data->username) && !empty($data->password) && !empty($data->email)) {
    try {
        $query = "INSERT INTO usuarios (username, password, email) VALUES (:username, :password, :email)";
        $stmt = $db->prepare($query);

        $hashed_password = password_hash($data->password, PASSWORD_DEFAULT);

        $stmt->bindParam(':username', $data->username);
        $stmt->bindParam(':password', $hashed_password);
        $stmt->bindParam(':email', $data->email);

        if ($stmt->execute()) {
            http_response_code(201); // Created
            echo json_encode(["exito" => true, "mensaje" => "Usuario creado exitosamente.", "id" => $db->lastInsertId()]);
        } else {
            http_response_code(503); // Service Unavailable
            echo json_encode(["exito" => false, "mensaje" => "No se pudo crear el usuario."]);
        }
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            http_response_code(400); // Bad Request
            echo json_encode(["exito" => false, "mensaje" => "El nombre de usuario o email ya existe."]);
        } else {
            http_response_code(500); // Internal Server Error
            echo json_encode(["exito" => false, "mensaje" => "Error de base de datos: " . $e->getMessage()]);
        }
    }
} else {
    http_response_code(400); // Bad Request
    echo json_encode(["exito" => false, "mensaje" => "Faltan datos. Asegúrese de enviar username, password y email."]);
}
?>
