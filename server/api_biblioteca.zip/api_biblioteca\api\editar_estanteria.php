<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: PUT");

require_once '../config/conexion.php';

$conexion = new Conexion();
$db = $conexion->getConexion();

$data = json_decode(file_get_contents("php://input"));

if (!empty($data->estanteria_id) && !empty($data->nuevo_titulo)) {
    try {
        $query = "UPDATE estanterias SET titulo = :nuevo_titulo WHERE id = :estanteria_id";
        $stmt = $db->prepare($query);

        $stmt->bindParam(':nuevo_titulo', $data->nuevo_titulo);
        $stmt->bindParam(':estanteria_id', $data->estanteria_id);

        if ($stmt->execute()) {
            if ($stmt->rowCount() > 0) {
                http_response_code(200); // OK
                echo json_encode(["exito" => true, "mensaje" => "Estantería actualizada exitosamente."]);
            } else {
                http_response_code(404); // Not Found (no rows updated, either not found or title was identical)
                echo json_encode(["exito" => false, "mensaje" => "No se encontró la estantería o el nombre es el mismo."]);
            }
        } else {
            http_response_code(503); // Service Unavailable
            echo json_encode(["exito" => false, "mensaje" => "No se pudo actualizar la estantería."]);
        }
    } catch (PDOException $e) {
        http_response_code(500); // Internal Server Error
        echo json_encode(["exito" => false, "mensaje" => "Error de base de datos: " . $e->getMessage()]);
    }
} else {
    http_response_code(400); // Bad Request
    echo json_encode(["exito" => false, "mensaje" => "Faltan datos. Asegúrese de enviar estanteria_id y nuevo_titulo."]);
}
?>
