<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST"); 

require_once '../config/conexion.php';

$conexion = new Conexion();
$db = $conexion->getConexion();

// Leemos el JSON enviado (ideal si usas Volley JsonObjectRequest POST)
$data = json_decode(file_get_contents("php://input"));

// Vamos a permitir buscar por ISBN o por Título
$isbn = !empty($data->isbn) ? $data->isbn : "";
$titulo = !empty($data->titulo) ? $data->titulo : "";

try {
    // Si mandan el ISBN, buscamos por ISBN exacto
    if ($isbn != "") {
        $query = "SELECT isbn, titulo, autor, editorial FROM libros WHERE isbn = :isbn";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':isbn', $isbn);
    } 
    // Si mandan el Título, buscamos coincidencias parciales (LIKE)
    else if ($titulo != "") {
        $query = "SELECT isbn, titulo, autor, editorial FROM libros WHERE titulo LIKE :titulo";
        $stmt = $db->prepare($query);
        $titulo_like = "%" . $titulo . "%";
        $stmt->bindParam(':titulo', $titulo_like);
    } 
    // Si no mandan nada, devolvemos error
    else {
        http_response_code(400);
        echo json_encode(["mensaje" => "Debes enviar un isbn o un titulo para buscar."]);
        exit();
    }

    $stmt->execute();
    $num = $stmt->rowCount();

    if ($num > 0) {
        $libros_arr = array();
        $libros_arr["libros"] = array();

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            $libro_item = array(
                "isbn" => $isbn,
                "titulo" => $titulo,
                "autor" => $autor,
                "editorial" => $editorial
            );
            array_push($libros_arr["libros"], $libro_item);
        }

        http_response_code(200); // OK
        echo json_encode($libros_arr);
    } else {
        http_response_code(200); 
        echo json_encode(["libros" => []]); // Devolvemos lista vacía si no hay resultados
    }
} catch (PDOException $e) {
    http_response_code(500); 
    echo json_encode(["mensaje" => "Error de base de datos: " . $e->getMessage()]);
}
?>
