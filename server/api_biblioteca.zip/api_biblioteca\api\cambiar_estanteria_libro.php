<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: PUT");

require_once '../config/conexion.php';

$conexion = new Conexion();
$db = $conexion->getConexion();

$data = json_decode(file_get_contents("php://input"));

if (!empty($data->libro_id) && !empty($data->vieja_estanteria_id) && !empty($data->nueva_estanteria_id)) {
    try {
        $query = "UPDATE estanteria_libro 
                  SET estanteria_id = :nueva_estanteria_id 
                  WHERE libro_id = :libro_id AND estanteria_id = :vieja_estanteria_id";
        $stmt = $db->prepare($query);

        $stmt->bindParam(':nueva_estanteria_id', $data->nueva_estanteria_id);
        $stmt->bindParam(':libro_id', $data->libro_id);
        $stmt->bindParam(':vieja_estanteria_id', $data->vieja_estanteria_id);

        if ($stmt->execute()) {
            if ($stmt->rowCount() > 0) {
                http_response_code(200); // OK
                echo json_encode(["exito" => true, "mensaje" => "El libro se movió a la nueva estantería."]);
            } else {
                http_response_code(404); // Not Found
                echo json_encode(["exito" => false, "mensaje" => "No se encontró el libro en la estantería especificada."]);
            }
        } else {
            http_response_code(503); // Service Unavailable
            echo json_encode(["exito" => false, "mensaje" => "No se pudo cambiar la estantería del libro."]);
        }
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { // Duplicate entry
            http_response_code(400); // Bad Request
            echo json_encode(["exito" => false, "mensaje" => "El libro ya se encuentra en la estantería destino."]);
        } else {
            http_response_code(500); // Internal Server Error
            echo json_encode(["exito" => false, "mensaje" => "Error de base de datos: " . $e->getMessage()]);
        }
    }
} else {
    http_response_code(400); // Bad Request
    echo json_encode(["exito" => false, "mensaje" => "Faltan datos. Envíe libro_id, vieja_estanteria_id y nueva_estanteria_id."]);
}
?>
