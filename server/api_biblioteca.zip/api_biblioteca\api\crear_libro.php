<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/conexion.php';

$conexion = new Conexion();
$db = $conexion->getConexion();

// Obtener datos enviados en JSON (ideal para Volley con JSONRequest)
$data = json_decode(file_get_contents("php://input"));

if (!empty($data->isbn) && !empty($data->titulo) && !empty($data->autor) && !empty($data->editorial)) {
    try {
        $query = "INSERT INTO libros (isbn, titulo, autor, editorial) VALUES (:isbn, :titulo, :autor, :editorial)";
        $stmt = $db->prepare($query);

        $stmt->bindParam(':isbn', $data->isbn);
        $stmt->bindParam(':titulo', $data->titulo);
        $stmt->bindParam(':autor', $data->autor);
        $stmt->bindParam(':editorial', $data->editorial);

        if ($stmt->execute()) {
            http_response_code(201); // Created
            echo json_encode([
                "exito"   => true,
                "mensaje" => "Libro creado exitosamente.",
                "id"      => (int) $db->lastInsertId()
            ]);
        } else {
            http_response_code(503); // Service Unavailable
            echo json_encode(["exito" => false, "mensaje" => "No se pudo crear el libro."]);
        }
    } catch (PDOException $e) {
        // Manejar el error de ISBN duplicado
        if ($e->getCode() == 23000) {
            http_response_code(400); // Bad Request
            echo json_encode(["exito" => false, "mensaje" => "El ISBN ya existe."]);
        } else {
            http_response_code(500); // Internal Server Error
            echo json_encode(["exito" => false, "mensaje" => "Error de base de datos: " . $e->getMessage()]);
        }
    }
} else {
    http_response_code(400); // Bad Request
    echo json_encode(["exito" => false, "mensaje" => "Faltan datos. Asegúrese de enviar isbn, titulo, autor y editorial."]);
}
?>
